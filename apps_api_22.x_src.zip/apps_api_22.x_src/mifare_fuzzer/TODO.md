
# Flipperzero Mifare Fuzzer - TODO

- Create a list of manufacturer codes for 7byte UIDs. _(Now it's fixed to: 0x04 = NXP Semiconductors Germany)_
    - https://github.com/Proxmark/proxmark3/blob/master/client/taginfo.c
    - https://stackoverflow.com/questions/37837730/mifare-cards-distinguish-between-4-byte-and-7-byte-uids
    - https://stackoverflow.com/questions/31233652/how-to-detect-manufacturer-from-nfc-tag-using-android

- Add saving option

- Emulate a full card and not only the UID
