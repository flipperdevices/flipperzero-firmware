# TODO:

1. Better (faster) detection of delay in a nested attack
2. Fix infinite calibration on static encrypted nonce tags
3. HardNested attack

## Thinking about:

1. Files (.nonces and .keys) in Flipper file format (why?)
