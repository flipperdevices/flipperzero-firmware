#include <notification/notification_messages.h>

void play_happy_bump(void* context);

void play_bad_bump(void* context);

void play_long_bump(void* context);

