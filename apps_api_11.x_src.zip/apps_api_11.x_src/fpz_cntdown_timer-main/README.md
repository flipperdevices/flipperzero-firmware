## Simple count down timer application for flipper zero

### How to use
`up/down`: set second/minute/hour value.

`ok`: start/stop counting.

`long press on ok`: stop counting and reset counter.

`left/right`: select second/minute/hour value.

