# FlipperZero-Etch-A-Sketch
Turn the Flipper Zero into an Etch A Sketch

This is a modification of the paint app.