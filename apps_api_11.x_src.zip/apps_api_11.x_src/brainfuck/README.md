# FlipperZeroBrainfuck

Brainfuck interpreter and editor for the F0.  
Supports text inputs and outputs.  
Blue LED indicates program is running.  

![Screenshot-20230117-202147](https://user-images.githubusercontent.com/16545187/213004616-8846e897-506e-4510-8012-fd2fe2bbe8a1.png)

![Screenshot-20230117-202208](https://user-images.githubusercontent.com/16545187/213004659-d74751d2-76c4-4a7b-a0f2-f58623478b95.png)
