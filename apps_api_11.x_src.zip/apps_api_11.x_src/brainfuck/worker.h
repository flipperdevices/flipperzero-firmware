#include "brainfuck_i.h"

void initWorker(BFApp* application);
char* workerGetOutput();
int getStackSize();
int getOpCount();
int getStatus();
void beginWorker();