#pragma once

/**
 * Index of dependencies for the main app
*/

#include <furi.h>
#include <furi_hal.h>
#include "helpers/time.h"