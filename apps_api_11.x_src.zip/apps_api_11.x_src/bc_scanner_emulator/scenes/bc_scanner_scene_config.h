ADD_SCENE(bc_scanner, file_select, FileSelect)
ADD_SCENE(bc_scanner, work, Work)
ADD_SCENE(bc_scanner, error, Error)
