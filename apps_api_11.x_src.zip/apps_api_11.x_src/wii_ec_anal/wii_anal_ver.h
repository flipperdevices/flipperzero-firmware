#ifndef  WII_ANAL_VER_H_
#define  WII_ANAL_VER_H_

#include  "gfx/images.h"

#define  VER_MAJ  &img_3x5_1
#define  VER_MIN  &img_3x5_0

#endif //WII_ANAL_VER_H_
