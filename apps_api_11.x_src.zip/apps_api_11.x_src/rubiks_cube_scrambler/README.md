# Rubik's Cube Scrambler FAP

## Where to start?
Install the .fap file and put it in your apps folder

## What does what?
The On/Off button toggles the vibration notification on and off. The "New" button generates a new scramble. The scramble letters correspond with the following moves: R = Right, L = Left, U = Up, D = Down, F = Front, B = Back. The number after the letter indicates how many times to turn that face. For example, R2 means to turn the right face twice. The ' symbol indicates a counter-clockwise turn. For example, R' means to turn the right face counter-clockwise once.

<img src="assets/1.png">

# A special thanks to Tanish for their c scrambler example 🙏
https://github.com/TanishBhongade/RubiksCubeScrambler-C/

