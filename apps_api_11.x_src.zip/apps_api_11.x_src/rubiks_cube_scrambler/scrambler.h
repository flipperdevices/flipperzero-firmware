void scrambleReplace ();
void genScramble ();
void valid ();
int getRand (int upr,int lwr);
char *printData ();
void writeToFile ();
