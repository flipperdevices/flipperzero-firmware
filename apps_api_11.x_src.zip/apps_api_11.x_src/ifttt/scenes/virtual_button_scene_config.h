ADD_SCENE(virtual_button, start, Start)
ADD_SCENE(virtual_button, send_view, SendView)
ADD_SCENE(virtual_button, about_view, AboutView)
