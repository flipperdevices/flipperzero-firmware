#include <gui/canvas.h>

void game_2048_draw_number(Canvas* const canvas, uint8_t x, uint8_t y, int number);