# The Flipper Zero Calculator
A scalable robust calculator application for the Flipper Zero
