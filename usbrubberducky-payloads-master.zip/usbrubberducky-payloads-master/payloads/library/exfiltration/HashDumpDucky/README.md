**Title: HashDumpDucky**

<p>Author: 0iphor13<br>
OS: Windows<br>
Requirements: DuckyScript 3.0<br>
Version: 1.0</p>

:bangbang: | This is just meant to be a PoC, as this method of Hashdump will result in empty, default hashes on recent versions of Windows.

**Instruction:**

Bring some time... This payload will run an obfuscated script to dump user hashes and exfiltrate the Administrator hash via Keystroke Reflection Method.

#
**Instruction:**

Compile this payload with payloadstudio, place it inside of your Ducky as inject.bin and you are good to go
#
Exfiltrate the out.txt file and try to crack the hashes.
![alt text](https://github.com/0iphor13/usbrubberducky-payloads/blob/master/payloads/library/exfiltration/HashDumpDucky/hash.png)

*props to Nikhil Mittal*
