# Nmap Recon

- Title:            Nmap Recon
- Author:           TW-D
- Version:          1.0
- Target:           Any
- Category:         Recon
- Attackmode:       RNDIS_ETHERNET

## Description

Ports Scanning with Nmap.

## Configuration

From "nmap-recon_payload.txt" change the value of the protocol for **ATTACKMODE** :
```

######## SETUP ########

LED SETUP

##
# (Windows) ATTACKMODE RNDIS_ETHERNET
# or
# (Mac and Linux) ATTACKMODE ECM_ETHERNET
##
ATTACKMODE RNDIS_ETHERNET


```

## Trigger

>
> __nmap-recon
>