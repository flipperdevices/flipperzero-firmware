# Hide/Unhide Startbar
* Author: Cribbit 
* Version: 1.0
* Target: Windows 7+ (Powershell)
* Category: pranks
* Attackmode: HID

## Description
Hides the Window Start bar

## Change Log
| Version | Changes                       |
| ------- | ------------------------------|
| 1.0     | Initial release               |

## Match
* hide_start
* show_start
