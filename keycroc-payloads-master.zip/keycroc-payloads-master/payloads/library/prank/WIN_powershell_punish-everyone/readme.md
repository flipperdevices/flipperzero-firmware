# Punish @everyone
* Author: Cribbit 
* Version: 1.0
* Target: Windows 7+ (Powershell)
* Category: pranks
* Attackmode: HID

## Change Log
| Version | Changes                       |
| ------- | ------------------------------|
| 1.0     | Initial release               |

## Description
Punish the user for typing @everyone with a high pitch sound

## Match
(?i)@everyone

## Configuration
Beep takes a frequency between 37 and 32767 and a time.
