# Hak5 ascii art
* Author: Cribbit 
* Version: 1.0
* Target: any
* Category: ascii
* Attackmode: HID
* Prop: Darren Kitchen and Everyone at Hak5 past and present

## Description
Replaces hak5 with ascii art version

## Change Log
| Version | Changes                       |
| ------- | ------------------------------|
| 1.0     | Initial release               |


## Match
(?i)hak5

## Configuration
none
