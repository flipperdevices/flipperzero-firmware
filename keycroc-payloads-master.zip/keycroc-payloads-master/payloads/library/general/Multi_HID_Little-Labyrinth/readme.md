# Little Labyrinth
* Author: Cribbit 
* Version: 1.1
* Target: any
* Category: General
* Attackmode: HID
* Props: Andrew Petro - BashVenture and all the Hak5 team!!!

## Change Log
| Version | Changes                       |
| ------- | ------------------------------|
| 1.0     | Initial release               |
| 1.1     | Added fetch quest             |

## Description
Quacking text adventure

Open a text editor, start the game and enjoy this basic text adventure.

## Match
shall we play a game

## Commands
* n = north
* e = east
* s = south
* w = west
* i = interact
* q = quit
