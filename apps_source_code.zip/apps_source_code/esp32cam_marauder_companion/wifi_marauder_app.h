#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#define WIFI_MARAUDER_APP_VERSION "v0.3.3"

typedef struct WifiMarauderApp WifiMarauderApp;

#ifdef __cplusplus
}
#endif
