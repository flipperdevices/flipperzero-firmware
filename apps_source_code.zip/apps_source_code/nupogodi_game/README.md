# Игра Ну, погоди! для Flipper Zero

<div align="center">
<img src=".flipcorg/gallery/screenshot.jpg" width="275">
</div>

[![FlipC.org](https://flipc.org/sionyx/flipper_nupogodi/badge?branch=main)](https://flipc.org/sionyx/flipper_nupogodi?branch=main)