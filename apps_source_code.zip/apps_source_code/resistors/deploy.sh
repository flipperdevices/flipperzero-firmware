#!/bin/bash

ufbt launch
