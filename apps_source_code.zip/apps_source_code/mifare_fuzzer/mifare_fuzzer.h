#pragma once

typedef struct MifareFuzzerApp MifareFuzzerApp;
