#pragma once

int airmon_aqi(float pm2_5, float pm10);
const char* airmon_aqi_level(int aqi);