# fz-reaction-game [![FlipC.org](https://flipc.org/Milk-Cool/fz-reaction-game/badge?branch=main)](https://flipc.org/Milk-Cool/fz-reaction-game?branch=main)
A simple reaction test for the flipper zero.
