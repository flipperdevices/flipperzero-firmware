# Flipper-DVD-Bounce
**simple dvd-bounce application for flipper**

Y'know how dvd players got that thing that bounces around?

*This is that*
