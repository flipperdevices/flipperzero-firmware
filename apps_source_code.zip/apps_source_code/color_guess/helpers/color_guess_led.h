

void led_set_rgb(void* context, int red, int green, int blue);

void led_reset(void* context);
