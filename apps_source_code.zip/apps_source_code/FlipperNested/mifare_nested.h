#pragma once

typedef struct MifareNested MifareNested;
