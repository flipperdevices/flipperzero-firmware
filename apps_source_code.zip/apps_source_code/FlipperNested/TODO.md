# TODO:

1. Better (faster) detection of delay in a nested attack
