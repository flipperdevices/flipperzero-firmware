#include <stdbool.h>
#include <stdint.h>

char* audio_modes_text[2] = {
    "Internal",
    "External",
};
bool audio_modes_values[2] = {false, true};