# <img src="./xbox_controller.png" height="20px" /> Xbox Controller for Flipper Zero

<img src="https://i.imgur.com/kfxmusm.png" height="256px" />


## Related things

 - IR codes for XBOX: [Lucaslhm/Flipper-IRDB/Consoles/Microsoft](https://github.com/Lucaslhm/Flipper-IRDB/tree/main/Consoles/Microsoft)
