# SCD30 Reader

Expects the device to have address 0x61. Connect SCL to C0, SDA to C1, ground to GND and power to 3V3.
