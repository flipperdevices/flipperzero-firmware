ADD_SCENE(ttt_multi, start, Start)
ADD_SCENE(ttt_multi, local, Local)