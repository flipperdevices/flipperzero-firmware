#pragma once

#include <furi.h>

#define TAG "FlippPomodoro"