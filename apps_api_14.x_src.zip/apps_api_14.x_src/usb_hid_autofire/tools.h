#ifndef FLIPPERZERO_FIRMWARE_TOOLS_H
#define FLIPPERZERO_FIRMWARE_TOOLS_H

void strrev(char *arr, int start, int end);
char *itoa(int number, char *arr, int base);

#endif //FLIPPERZERO_FIRMWARE_TOOLS_H
