ADD_SCENE(color_guess, start, Start)
ADD_SCENE(color_guess, color_set, ColorSet)
ADD_SCENE(color_guess, play, Play)