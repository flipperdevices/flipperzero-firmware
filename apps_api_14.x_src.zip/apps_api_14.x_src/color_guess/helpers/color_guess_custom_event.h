#pragma once

typedef enum {
    ColorGuessCustomEventColorSetUp,
    ColorGuessCustomEventColorSetDown,
    ColorGuessCustomEventColorSetLeft,
    ColorGuessCustomEventColorSetRight,
    ColorGuessCustomEventColorSetOk,
    ColorGuessCustomEventColorSetBack,
    ColorGuessCustomEventPlayUp,
    ColorGuessCustomEventPlayDown,
    ColorGuessCustomEventPlayLeft,
    ColorGuessCustomEventPlayRight,
    ColorGuessCustomEventPlayOk,
    ColorGuessCustomEventPlayBack,
} ColorGuessCustomEvent;