sudo tccutil reset All
