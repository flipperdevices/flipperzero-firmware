//#pragma once

#include <stdint.h>
#include "color_guess_icons.h"

const Icon* digits[17] = {
    &I_digit_0_10x14,
    &I_digit_1_10x14,
    &I_digit_2_10x14,
    &I_digit_3_10x14,
    &I_digit_4_10x14,
    &I_digit_5_10x14,
    &I_digit_6_10x14,
    &I_digit_7_10x14,
    &I_digit_8_10x14,
    &I_digit_9_10x14,
    &I_digit_a_10x14,
    &I_digit_b_10x14,
    &I_digit_c_10x14,
    &I_digit_d_10x14,
    &I_digit_e_10x14,
    &I_digit_f_10x14,
    &I_digit_x_10x14};
