#pragma once

typedef struct NfcMagicDevice NfcMagicDevice;

typedef struct NfcMagic NfcMagic;
