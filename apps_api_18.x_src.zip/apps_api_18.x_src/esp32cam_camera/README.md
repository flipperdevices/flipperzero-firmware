**Buy one:** [Tindie Store](https://www.tindie.com/products/eried/flipper-zero-mayhem-hat-esp32btcamerasdnrf24/)

**Get started:** [wiki/First-steps](https://github.com/eried/flipperzero-mayhem/wiki/First-steps)

![image](https://user-images.githubusercontent.com/1091420/219699372-189b8b39-74ec-4bdc-a0cd-042887992f68.png)
