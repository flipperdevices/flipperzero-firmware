#pragma once

#include "video_player.h"
//#include "video_player_hal.h"

VideoPlayerApp* init_player();
void deinit_player(VideoPlayerApp* tracker);