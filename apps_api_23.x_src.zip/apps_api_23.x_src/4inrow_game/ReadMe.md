Four in row for flipper zero!!
