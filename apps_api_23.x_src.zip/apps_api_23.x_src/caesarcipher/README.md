# Caesar Cipher

A [caesar cipher](https://en.wikipedia.org/wiki/Caesar_cipher) encoder for the Flipper Zero device.

![input](img/1.png)
![output](img/2.png)

## Usage

Start app, painfully input your ciphertext with the onscreen keyboard. Replace spaces with underscores. Hit "Save", scroll output.

## Compiling

```
./fbt firmware_caesar_cipher
```

