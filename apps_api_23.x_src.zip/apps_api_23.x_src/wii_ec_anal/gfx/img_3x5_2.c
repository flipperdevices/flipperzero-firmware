// ######
// ....##
// ######
// ##....
// ######

#include "images.h"

const image_t img_3x5_2 = {3, 5, false, 2, 0, {0xE7, 0xCE}};
