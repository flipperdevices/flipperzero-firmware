# fz-schip [![FlipC.org](https://flipc.org/Milk-Cool/fz-schip/badge?branch=main)](https://flipc.org/Milk-Cool/fz-schip?branch=main)
A SUPER-CHIP emulator for the Flipper Zero

## I know there's something wrong with it but i can't figure out what it is so the current state of this project is public testing. Please let me know if there are any issues with it.

## Installing
Just click the FAP badge in the title.

## Uploading ROMs
Launch the app, and the folder `/ext/schip` will be created. Then upload your .ch8 files to that folder and enjoy your emulator!
