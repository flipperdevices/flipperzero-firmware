#include <stdint.h>

#define SYSEX_BUFFER_LEN 16