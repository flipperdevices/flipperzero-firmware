# Changelog

## 0.3
- add a delay between key-presses (with left/right buttons)

## 0.2
- update icon

## 0.1
- initial release of the USB HID Autofire application
