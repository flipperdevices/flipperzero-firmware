# Changelog

## 0.2
- update icon

## 0.1
- initial release of the USB HID Autofire application
