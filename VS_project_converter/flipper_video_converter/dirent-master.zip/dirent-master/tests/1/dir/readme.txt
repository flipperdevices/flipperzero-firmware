This file ensures that the directory dir will be created accordingly when
you unzip dirent to your computer.  The directory itself is needed by the
test program t-dirent.
